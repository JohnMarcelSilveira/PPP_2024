package proxy.model;

public interface Model {
    public int getIdade();
    public boolean isHabilitado();
}
