package jogos;

public class Jogo2 {

    public void executar() {
        System.out.println("Atirando no jogo de tiro");
    }

    public void desfazer() {
        System.out.println("Recarregando no jogo de tiro");
    }
}
