package jogos;

public class Jogo3 {

    public void executar() {
        System.out.println("Pulando no jogo de plataforma");
    }

    public void desfazer() {
        System.out.println("Voltando ao chão no jogo de plataforma");
    }
}
