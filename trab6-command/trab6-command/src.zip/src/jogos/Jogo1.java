package jogos;

public class Jogo1 {

    public void executar() {
        System.out.println("Acelerando carro no jogo de corrida");
    }

    public void desfazer() {
        System.out.println("Desacelerando carro no jogo de corrida");
    }
}
