package jogos;

public class Jogo4 {

    public void executar() {
        System.out.println("Atacando no jogo de luta");
    }

    public void desfazer() {
        System.out.println("Defendendo no jogo de luta");
    }
}
