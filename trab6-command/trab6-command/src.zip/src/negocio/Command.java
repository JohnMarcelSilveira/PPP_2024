package negocio;

public interface Command {

    public void botaoA();

    // opcional
    public void botaoB();

}
