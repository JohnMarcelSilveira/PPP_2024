package negocio;

public interface Observer {
    void update(String status);
}
